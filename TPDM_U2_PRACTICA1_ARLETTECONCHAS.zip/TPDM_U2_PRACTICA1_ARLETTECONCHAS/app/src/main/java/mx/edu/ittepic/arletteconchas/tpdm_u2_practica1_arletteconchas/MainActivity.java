package mx.edu.ittepic.arletteconchas.tpdm_u2_practica1_arletteconchas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView lista;
    Proyecto[] proyectos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista = findViewById(R.id.listapr);
    }

    @Override
    protected void onStart() {
        Proyecto p = new Proyecto(this);
        proyectos = p.consultar();
        String [] busqueda=null;
        if(proyectos==null){
            busqueda = new String[1];
            busqueda[0]="¡¡NO HAY PROYECTOS AÚN!!";
        }else{
            busqueda = new String[proyectos.length];
            for (int i=0;i<proyectos.length;i++){
                Proyecto temp= proyectos[i];
                busqueda[i]=temp.getDescripcion()+"\n"+temp.getUbicacion();
            }
        }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1,busqueda);
        lista.setAdapter(adaptador);
        super.onStart();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuopciones,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){
            case R.id.Insertar:
                Intent inserta= new Intent(this,Main2Activity.class);
                startActivity(inserta);
                break;
            case R.id.Consultar:
                Intent consulta= new Intent(this,Main3Activity.class);
                startActivity(consulta);
                break;
            /*case R.id.Actualizar:
                Intent elimina= new Intent(this,Main4Activity.class);
                startActivity(elimina);
                break;*/
        }

        return super.onOptionsItemSelected(item);
    }
}
