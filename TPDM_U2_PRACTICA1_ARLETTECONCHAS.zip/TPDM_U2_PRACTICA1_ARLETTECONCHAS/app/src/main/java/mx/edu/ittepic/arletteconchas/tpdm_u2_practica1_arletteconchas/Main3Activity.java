package mx.edu.ittepic.arletteconchas.tpdm_u2_practica1_arletteconchas;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class Main3Activity extends AppCompatActivity {
    EditText consultatexto;
    ListView lista;
    Button consulta, cerrar;
    Proyecto[] proyectos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        consultatexto = findViewById(R.id.idConsultaTexto);
        lista = findViewById(R.id.listaConsulta);
        consulta = findViewById(R.id.botonConsultar);
        cerrar = findViewById(R.id.botonCerrar);

        consulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                consultar();
            }
        });

        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cerrar();
            }
        });

    }

    public void consultar(){
        Proyecto p = new Proyecto(this);
        String [] busqueda2=null;
            proyectos = p.consultar("DESCRIPCION",consultatexto.getText().toString());
            if(proyectos==null){
                busqueda2 = new String[1];
                busqueda2[0]="NO HAY PROYECTOS";
            }else{
                busqueda2 = new String[proyectos.length];
                for (int i=0;i<proyectos.length;i++){
                    Proyecto temp= proyectos[i];
                    busqueda2[i]=temp.getDescripcion()+"\n"+temp.getUbicacion();
                }
            }
        ArrayAdapter<String> adaptador = new ArrayAdapter<String>(Main3Activity.this,
                android.R.layout.simple_list_item_1,busqueda2);
        lista.setAdapter(adaptador);
    }

    public void cerrar(){
        Intent cierra= new Intent(this,MainActivity.class);
        startActivity(cierra);
    }
}