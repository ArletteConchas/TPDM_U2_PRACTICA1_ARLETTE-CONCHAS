package mx.edu.ittepic.arletteconchas.tpdm_u2_practica1_arletteconchas;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.SimpleDateFormat;

public class Main2Activity extends AppCompatActivity {
    EditText descripcion, ubicacion, fecha, presupuesto;
    Button insertar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        descripcion = findViewById(R.id.idDescripcion);
        ubicacion = findViewById(R.id.idUbicacion);
        fecha = findViewById(R.id.idFecha);
        presupuesto = findViewById(R.id.idPresupuesto);
        insertar = findViewById(R.id.idInsertar);

        insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertar();
            }
        });
    }

    private void insertar() {
        try {
            String mensaje = "";
            Proyecto p = new Proyecto(this);
            boolean respuesta = p.insertar(new Proyecto(0, descripcion.getText().toString(),
                    ubicacion.getText().toString(),
                    new SimpleDateFormat("dd/MM/yyyy").parse(fecha.getText().toString()),
                    Float.parseFloat(presupuesto.getText().toString())));
            if (respuesta) {
                mensaje = "¡EXITO! SE PUDO INSERTAR";
            } else {
                mensaje = "¡ERROR! NO SE PUDO ISNERTAR";
            }
            AlertDialog.Builder alerta =new AlertDialog.Builder(this);
            alerta.setTitle("ATENCION").setMessage(mensaje).setPositiveButton("OK",null).show();
        }catch (Exception e){

        }
    }
}
